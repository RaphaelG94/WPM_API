﻿namespace Bitstream.Web.Code.Scheduler.Queue.Workers
{
    public interface IWorkerServiceBase
    {
        void LoadAndProcess();
    }
}
