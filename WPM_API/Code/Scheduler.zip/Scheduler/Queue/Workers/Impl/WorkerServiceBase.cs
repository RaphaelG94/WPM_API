﻿using Bitstream.Data.Infrastructure;
using Bitstream.Web.Code.Infrastructure;

namespace Bitstream.Web.Code.Scheduler.Queue.Workers.Impl
{
    public abstract class WorkerServiceBase
    {
        public abstract void LoadAndProcess();

        protected UnitOfWork CreateUnitOfWork()
        {
            return AppDependencyResolver.Current.CreateUoWinCurrentThread();
        }
    }
}