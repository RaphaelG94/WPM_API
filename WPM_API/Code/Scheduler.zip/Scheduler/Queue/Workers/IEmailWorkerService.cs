﻿namespace Bitstream.Web.Code.Scheduler.Queue.Workers
{
    public interface IEmailWorkerService: IWorkerServiceBase
    {
        void ProcessSchedulerSync(string schedulerId);
    }
}
