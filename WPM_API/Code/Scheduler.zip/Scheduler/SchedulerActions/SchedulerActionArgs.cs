﻿using Bitstream.Data.Files;
using Bitstream.Data.Infrastructure;
using Bitstream.Web.Code.Infrastructure;

namespace Bitstream.Web.Code.Scheduler.SchedulerActions
{
    public class SchedulerActionArgs
    {
        public UnitOfWork UnitOfWork { get; set; }
        public IPathResolver PathResolver { get; set; }
        public IAttachmentService AttachmentService { get; set; }
    }
}