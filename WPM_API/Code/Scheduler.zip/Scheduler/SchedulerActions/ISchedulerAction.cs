﻿using Bitstream.Web.Code.Scheduler.DataModels;

namespace Bitstream.Web.Code.Scheduler.SchedulerActions
{
    public interface ISchedulerAction
    {
        void Process(SchedulerData schedulerData);
    }
}