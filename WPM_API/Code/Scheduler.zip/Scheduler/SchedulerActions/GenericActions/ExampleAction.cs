﻿using Bitstream.Common.Logs;
using Bitstream.Web.Code.Scheduler.SchedulerModels.GenericActionModels;

namespace Bitstream.Web.Code.Scheduler.SchedulerActions.GenericActions
{
    public class ExampleAction : SchedulerActionBase<ExampleActionModel>
    {
        public ExampleAction(SchedulerActionArgs args) : base(args)
        {
        }

        protected override void DoProcess(ExampleActionModel actionModel)
        {
            LogHolder.MainLog.Info("Example Action fired - " + actionModel.Value);
        }
    }
}