using Bitstream.Common;
using Bitstream.Web.Code.Scheduler.Attributes;
using Bitstream.Web.Code.Scheduler.DataModels;

namespace Bitstream.Web.Code.Scheduler.SchedulerModels.EmailBuilderModels
{
    [SchedulerActionType(Enums.SchedulerActionTypes.ResetPasswordEmail)]
    public class ResetPasswordNotificationEmailModel : SchedulerModelBase
    {
        public string UserForgotPasswordId { get; set; }

        public ResetPasswordNotificationEmailModel(string createdByUserId) : base(createdByUserId)
        {
        }

        protected override void DoFillFromSchedulerData(SchedulerData schedulerData)
        {
            UserForgotPasswordId = schedulerData.EntityId1;
        }

        protected override void DoFillSchedulerData(SchedulerData schedulerData)
        {
            schedulerData.EntityId1 = UserForgotPasswordId;
        }
    }
}