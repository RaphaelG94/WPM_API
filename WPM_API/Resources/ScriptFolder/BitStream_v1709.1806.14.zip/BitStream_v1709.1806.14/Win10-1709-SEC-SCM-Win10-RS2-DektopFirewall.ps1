﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "SEC-SCM-Win10-RS2-DektopFirewall"


### Computer Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall" -ValueName "PolicyVersion" -Type Dword -Value 538 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile" -ValueName "DefaultOutboundAction" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile" -ValueName "DisableNotifications" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile" -ValueName "EnableFirewall" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile" -ValueName "DefaultInboundAction" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -ValueName "LogDroppedPackets" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -ValueName "LogFileSize" -Type Dword -Value 16384 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -ValueName "LogSuccessfulConnections" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile" -ValueName "EnableFirewall" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile" -ValueName "DisableNotifications" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile" -ValueName "DefaultInboundAction" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile" -ValueName "DefaultOutboundAction" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -ValueName "LogSuccessfulConnections" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -ValueName "LogDroppedPackets" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -ValueName "LogFileSize" -Type Dword -Value 16384 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -ValueName "DefaultOutboundAction" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -ValueName "EnableFirewall" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -ValueName "DisableNotifications" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -ValueName "AllowLocalIPsecPolicyMerge" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -ValueName "AllowLocalPolicyMerge" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -ValueName "DefaultInboundAction" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -ValueName "LogFileSize" -Type Dword -Value 16384 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -ValueName "LogDroppedPackets" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -ValueName "LogSuccessfulConnections" -Type Dword -Value 1 | out-null
# PREFERENCES

### User Part
# REGISTRY
# PREFERENCES
