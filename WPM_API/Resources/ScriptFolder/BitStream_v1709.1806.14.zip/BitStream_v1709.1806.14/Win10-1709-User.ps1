﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "User"
$Theme="C:\Windows\Resources\Themes\COMPANY.theme" #Absoluter Pfad, keine Variablen!
$ScreenSaver="scrnsave.scr"

### Computer Part
### settings disabled ###


### User Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Explorer" -ValueName "HidePeopleBar" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaveActive" -Type String -Value "1" | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "SCRNSAVE.EXE" -Type String -Value $ScreenSaver | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaverIsSecure" -Type String -Value "0" | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaveTimeOut" -Type String -Value "480" | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableThirdPartySuggestions" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableWindowsSpotlightFeatures" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableWindowsSpotlightOnActionCenter" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableWindowsSpotlightWindowsWelcomeExperience" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableTailoredExperiencesWithDiagnosticData" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "ConfigureWindowsSpotlight" -Type Dword -Value 2 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "IncludeEnterpriseSpotlight" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Personalization" -ValueName "ThemeFile" -Type String -Value $Theme | out-null
   ### tattooing! ###
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" -ValueName "DisablePersonalDirChange" -Type Dword -Value 1 | out-null
# PREFERENCES
Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -ValueName "HideFileExt" -Type Dword -Value 0 -Context User -Action Replace #once
Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -ValueName "ShowInfoTip" -Type DWord -Value 0 -Context User -Action Replace #once
Set-GPPrefRegistryValue -Name $polname -Key "HKCU\.DEFAULT\Control Panel\Keyboard" -ValueName "InitialKeyboardIndicators" -Type String -Value "2147483650" -Context User -Action Update #once