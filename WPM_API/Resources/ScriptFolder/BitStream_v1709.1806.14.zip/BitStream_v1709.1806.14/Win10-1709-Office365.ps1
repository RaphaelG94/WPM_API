﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "Office365"

# Computer REGISTRY Part
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Officeupdate" -ValueName "enableautomaticupdates" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Officeupdate" -ValueName "hideenabledisableupdates" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Officeupdate" -ValueName "Hideupdatenotifications" -Type Dword -Value 1 | out-null

### not listed
#Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Office\16.0\Lync" -ValueName "Preventrun" -Type Dword -Value 1 | out-null

# User REGISTRY Part
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common" -ValueName "Autoorgidgetkey" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common" -ValueName "Qmenable" -Type Dword -Value 0 | out-null #"Microsoft Office 2016/Privacy/Trust Center -> Enable Customer Experience Improvement Program
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common" -ValueName "Updatereliabilitydata" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Feedback" -ValueName "Enabled" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Feedback" -ValueName "Includescreenshot" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Disableboottoofficestart" -Type Dword -Value 1 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Disablehyperlinkstowebtemplates" -Type Dword -Value 1 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Disableofficetemplates" -Type Dword -Value 1 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Sharedtemplates" -Type ExpandString -Value "\\%USERDNSDOMAIN%\%UserLocation%\Public\Office\Templates" | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Shownfirstrunoptin" -Type Dword -Value 1 | out-null #Microsoft Office 2016/Privacy/Trust Center -> Disable Opt-in Wizard on first run
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Skydrivesigninoption" -Type Dword -Value 0 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Usertemplates" -Type ExpandString -Value "HOMESHARE%HOMEPATH%Documents\Office Templates"| out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\General" -ValueName "Optindisable" -Type Dword -Value 1 | out-null #Microsoft Office 2016/Miscellaneous -> Suppress recommended settings dialog
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Internet" -ValueName "Onlinestorage" -Type Dword -Value 3 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Internet" -ValueName "Serviceleveloptions" -Type Dword -Value 1 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Licensing" -ValueName "Hidemanageaccountlink" -Type Dword -Value 1 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Roaming" -ValueName "Roamingsettingsdisabled" -Type Dword -Value 1 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Security\Trusted Locations" -ValueName "Allow User Locations" -Type Dword -Value 0 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Signin" -ValueName "Signinoptions" -Type Dword -Value 2 | out-null # 0=both IDs, 1=MSAccount only, 2=OrgID only, 3=None Allowed
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Firstrun" -ValueName "Bootedrtm" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Office\16.0\Firstrun" -ValueName "Disablemovie" -Type Dword -Value 1 | out-null

Set-GPRegistryValue -Name $polname -Key "HKCU\Software\policies\microsoft\office\16.0\Excel" -ValueName "Dontshowwhatsnew" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\policies\microsoft\office\16.0\Onenote" -ValueName "Dontshowwhatsnew" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\policies\microsoft\office\16.0\Outlook" -ValueName "Dontshowwhatsnew" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\policies\microsoft\office\16.0\Powerpoint" -ValueName "Dontshowwhatsnew" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\policies\microsoft\office\16.0\Visio" -ValueName "Dontshowwhatsnew" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\policies\microsoft\office\16.0\Word" -ValueName "Dontshowwhatsnew" -Type Dword -Value 1 | out-null

# User GPP Part
#Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Microsoft\Office\16.0\Registration" -ValueName "AcceptAllEulas" -Type Dword -Value 1 -Context User -Action Replace | out-null
#Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Microsoft\Office\16.0\Common\General" -ValueName "ShownFileFmtPrompt" -Type Dword -Value 1 -Context User -Action Replace | out-null
#Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Microsoft\Office\16.0\Outlook\Options\Calendar" -ValueName "WeekNum" -Type Dword -Value 1 -Context User -Action Replace | out-null
