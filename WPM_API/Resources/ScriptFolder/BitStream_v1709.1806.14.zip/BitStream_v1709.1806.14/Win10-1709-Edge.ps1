﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "Edge"
$homepage = "http://bitstream.de" + "/"
$EMsitelist = "file:///" + "\\test.lan\NETLOGON\COMPANY\LaF\COMPANY_enterprisemode_list.xml"   # "file:///" + $env:ProgramData + "BitStream\enterprisemode_list.xml"


### Computer Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Internet Settings" -ValueName "ProvisionedHomePages" -Type String -Value $homepage | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main" -ValueName "PreventFirstRunPage" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main" -ValueName "SendIntranetTraffictoInternetExplorer" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main" -ValueName "SyncFavoritesBetweenIEAndMicrosoftEdge" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main\EnterpriseMode" -ValueName "SiteList" -Type String -Value $EMsitelist | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\OpenSearch" -ValueName "SetDefaultSearchEngine" -Type String -Value "https://www.google.com/searchdomaincheck?format=opensearch" | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\ServiceUI" -ValueName "AllowWebContentOnNewTabPage" -Type Dword -Value 0 | out-null
# PREFERENCES

### User Part
# REGISTRY
# PREFERENCES
Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\microsoft.microsoftedge_8wekyb3d8bbwe\MicrosoftEdge\Main" -ValueName "HomeButtonEnabled" -Type Dword -Value 1 -Context User -Action Replace | out-null
Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\microsoft.microsoftedge_8wekyb3d8bbwe\MicrosoftEdge\LinksBar" -ValueName "Enabled" -Type Dword -Value 1 -Context User -Action Replace | out-null
Set-GPPrefRegistryValue -Name $polname -Key "HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\microsoft.microsoftedge_8wekyb3d8bbwe\MicrosoftEdge\Main" -ValueName "HomeButtonPage" -Type String -Value $homepage -Context User -Action Replace | out-null
