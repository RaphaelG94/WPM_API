﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "IE11"
$homepage = "http://bitstream.de" + "/"
$EMsitelist = "file:///" + "\\test.lan\NETLOGON\COMPANY\LaF\COMPANY_enterprisemode_list.xml"   # "file:///" + $env:ProgramData + "BitStream\enterprisemode_list.xml"


### Computer Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" -ValueName "DisableFirstRunCustomize" -Type Dword -Value 1 | out-null
Start-Sleep -Milliseconds 300
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\EnterpriseMode" -ValueName "SiteList" -Type String -Value $EMsitelist | out-null
Start-Sleep -Milliseconds 300
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\EnterpriseMode" -ValueName "RestrictIE" -Type Dword -Value 1 | out-null
Start-Sleep -Milliseconds 300
# PREFERENCES

### User Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Internet Explorer\Control Panel" -ValueName "HomePage" -Type Dword -Value 1 | out-null
Start-Sleep -Milliseconds 300
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Internet Explorer\Main" -ValueName "Start Page" -Type String -Value $homepage | out-null
Start-Sleep -Milliseconds 300
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Internet Explorer\Restrictions" -ValueName "NoHelpItemSendFeedback" -Type Dword -Value 1 | out-null #Feedbacksmiley
Start-Sleep -Milliseconds 300
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Internet Explorer\Restrictions" -ValueName "NoHelpItemTutorial" -Type Dword -Value 1 | out-null
Start-Sleep -Milliseconds 300
# PREFERENCES
