﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "Computersettings"
$LogonDomain = $env:USERDNSDOMAIN.ToLower()
$LockScreenImage="C:\ProgramData\COMPANY\LaF\COMPANY_lockscreen_yellow.jpg" #*.png and *.jpg is working! But neither "%ProgramData%\..." nor "%SystemDrive%\ProgramData\..." or "%ALLUSERSPROFILE%\..." will work!!!
$FileAssocList="C:\ProgramData\COMPANY\LaF\COMPANY_AppAssoc.xml"
$ScreenSaver="scrnsave.scr"


### Computer Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -ValueName "ManagePreviewBuilds" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -ValueName "ManagePreviewBuildsPolicyValue" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" -ValueName "DisableFileSyncNGSC" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" -ValueName "RequirePrivateStoreOnly" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ValueName "EnableFirstLogonAnimation" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ValueName "DefaultLogonDomain" -Type String -Value $LogonDomain | out-null #needs to be documented
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableWindowsConsumerFeatures" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" -ValueName "LockScreenImage" -Type String -Value $LockScreenImage | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" -ValueName "LockScreenOverlaysDisabled" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" -ValueName "NoChangingLockScreen" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "UserAuthentication" -Type Dword -Value 1 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "AllowDomainPINLogon" -Type Dword -Value 0 | out-null
#Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "BlockDomainPicturePassword" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "DefaultAssociationsConfiguration" -Type String -Value $FileAssocList | out-null
#Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" -ValueName "StartLayoutFile" -Type ExpandString -Value "C:\ProgramData\COMPANY\LaF_v1.0\LayoutModification.xml" | out-null
#Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" -ValueName "LockedStartLayout" -Type Dword -Value 1 | out-null
   ### tattooing! ###
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters" -ValueName "EnableMaxTokenSize" -Type Dword -Value 1 | out-null #use together with next setting only!
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters" -ValueName "MaxTokenSize" -Type Dword -Value 48000 | out-null #use together with above setting only!
# PREFERENCES

### User Part
### settings disabled ###

write-host "Don't forget to implement the SecTemplate and File.xml!!!!!"