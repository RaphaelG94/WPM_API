﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "SEC-SCM-Win10-RS2"


### Computer Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config" -ValueName "AutoConnectAllowedOEM" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\CredUI" -ValueName "EnumerateAdministrators" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -ValueName "NoDriveTypeAutoRun" -Type Dword -Value 255 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -ValueName "NoWebServices" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -ValueName "NoAutorun" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ValueName "MSAOptional" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ValueName "DisableAutomaticRestartSignOn" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ValueName "LocalAccountTokenFilterPolicy" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Biometrics\FacialFeatures" -ValueName "EnhancedAntiSpoofing" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\FVE" -ValueName "DisableExternalDMAUnderLock" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Internet Explorer\Feeds" -ValueName "DisableEnclosureDownload" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51" -ValueName "DCSettingIndex" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51" -ValueName "ACSettingIndex" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableWindowsConsumerFeatures" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -ValueName "AllowProtectedCreds" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\Application" -ValueName "MaxSize" -Type Dword -Value 32768 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\Security" -ValueName "MaxSize" -Type Dword -Value 196608 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\System" -ValueName "MaxSize" -Type Dword -Value 32768 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" -ValueName "NoDataExecutionPrevention" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" -ValueName "NoHeapTerminationOnCorruption" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" -ValueName "NoAutoplayfornonVolume" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -ValueName "AllowGameDVR" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Group Policy\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}" -ValueName "NoGPOListChanges" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Group Policy\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}" -ValueName "NoBackgroundPolicy" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer" -ValueName "AlwaysInstallElevated" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer" -ValueName "EnableUserControl" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation" -ValueName "AllowInsecureGuestAuth" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Network Connections" -ValueName "NC_ShowSharedAccessUI" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -ValueName "\\*\SYSVOL" -Type String -Value RequireMutualAuthentication=1,RequireIntegrity=1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -ValueName "\\*\NETLOGON" -Type String -Value RequireMutualAuthentication=1,RequireIntegrity=1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" -ValueName "NoLockScreenCamera" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" -ValueName "NoLockScreenSlideshow" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -ValueName "EnableScriptBlockLogging" -Type Dword -Value 1 | out-null
#Remove-GPRegistryValue-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -ValueName "**del.EnableScriptBlockInvocationLogging"
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "AllowDomainPINLogon" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "EnumerateLocalUsers" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "DontDisplayNetworkSelectionUI" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "EnableSmartScreen" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" -ValueName "ShellSmartScreenLevel" -Type String -Value Block | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy" -ValueName "fBlockNonDomain" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" -ValueName "AllowIndexingEncryptedStoresOrItems" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client" -ValueName "AllowDigest" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client" -ValueName "AllowUnencryptedTraffic" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client" -ValueName "AllowBasic" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service" -ValueName "AllowUnencryptedTraffic" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service" -ValueName "DisableRunAs" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service" -ValueName "AllowBasic" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine" -ValueName "MpEnablePus" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers" -ValueName "DisableWebPnPDownload" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers" -ValueName "DisableHTTPPrinting" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Rpc" -ValueName "RestrictRemoteClients" -Type Dword -Value 1 | out-null
#Remove-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "**del.fUseMailto"
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "fAllowToGetHelp" -Type Dword -Value 0 | out-null
#Remove-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "**del.fAllowFullControl"
#Remove-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "**del.MaxTicketExpiry"
#Remove-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "**del.MaxTicketExpiryUnits"
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "MinEncryptionLevel" -Type Dword -Value 3 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "fPromptForPassword" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "fDisableCdm" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "DisablePasswordSaving" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -ValueName "fEncryptRPCTraffic" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\WindowsInkWorkspace" -ValueName "AllowWindowsInkWorkspace" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft Services\AdmPwd" -ValueName "AdmPwdEnabled" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Policies\EarlyLaunch" -ValueName "DriverLoadPolicy" -Type Dword -Value 3 | out-null
# Tattooing!!!
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -ValueName "UseLogonCredential" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" -ValueName "DisableExceptionChainValidation" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -ValueName "SMB1" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Services\MrxSmb10" -ValueName "Start" -Type Dword -Value 4 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Services\Netbt\Parameters" -ValueName "NoNameReleaseOnDemand" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -ValueName "EnableICMPRedirect" -Type Dword -Value 0 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -ValueName "DisableIPSourceRouting" -Type Dword -Value 2 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -ValueName "DisableIPSourceRouting" -Type Dword -Value 2 | out-null
# PREFERENCES

### User Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CloudContent" -ValueName "DisableThirdPartySuggestions" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaveActive" -Type String -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaverIsSecure" -Type String -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKCU\Software\Policies\Microsoft\Windows\CurrentVersion\PushNotifications" -ValueName "NoToastApplicationNotificationOnLockScreen" -Type Dword -Value 1 | out-null
# PREFERENCES
