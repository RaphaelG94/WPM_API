﻿# GPO creation script for BitStream GmbH v1709.1806.14
#
# Author: Nicolas Voggenreiter (nicolas.voggenreiter@bitstream.de)

$Prefix = "Win10"
$Release = "1709"
$polname = $Prefix + "-" + $Release + "-" + "SEC-SCM-Win10-RS2-Edge"


### Computer Part
# REGISTRY
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main" -ValueName "FormSuggest Passwords" -Type String -Value "no" | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter" -ValueName "EnabledV9" -Type Dword -Value 1 | out-null  #Edge Browser
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter" -ValueName "PreventOverride" -Type Dword -Value 1 | out-null
Set-GPRegistryValue -Name $polname -Key "HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter" -ValueName "PreventOverrideAppRepUnknown" -Type Dword -Value 1 | out-null
# PREFERENCES

### User Part
# REGISTRY
# PREFERENCES
